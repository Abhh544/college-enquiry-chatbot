# AI-Powered College Enquiry Chatbot

A modern, responsive chatbot interface built with React and TypeScript that helps students get quick answers to common college-related questions.

## Features

- 💬 Real-time chat interface
- 🎨 Modern UI with Tailwind CSS
- 📱 Fully responsive design
- ⚡ Fast and lightweight
- 🤖 AI-powered responses
- 🎯 Accurate query matching

## Tech Stack

- React
- TypeScript
- Tailwind CSS
- Vite
- Lucide React Icons

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

## License

MIT