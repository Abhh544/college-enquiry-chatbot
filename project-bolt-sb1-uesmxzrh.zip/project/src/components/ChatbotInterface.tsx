import React, { useState, useEffect, useRef } from 'react';
import MessageList from './MessageList';
import MessageInput from './MessageInput';
import { Message } from '../types/chatTypes';
import { getResponse } from '../services/chatService';

const ChatbotInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I am the College Enquiry Assistant. How can I help you today?',
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setIsTyping(true);

    // Simulate processing time
    setTimeout(async () => {
      try {
        const responseText = await getResponse(text);
        
        // Add bot message
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: responseText,
          sender: 'bot',
          timestamp: new Date(),
        };
        
        setMessages((prev) => [...prev, botMessage]);
        setIsTyping(false);
      } catch (error) {
        console.error('Error getting response:', error);
        
        // Add error message
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: 'Sorry, I encountered an error. Please try again later.',
          sender: 'bot',
          timestamp: new Date(),
        };
        
        setMessages((prev) => [...prev, errorMessage]);
        setIsTyping(false);
      }
    }, 1000);
  };

  return (
    <div className="bg-white rounded-xl shadow-xl w-full max-w-md lg:max-w-lg xl:max-w-xl h-[600px] flex flex-col overflow-hidden transition-all duration-300 hover:shadow-2xl">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white">
        <h2 className="text-lg font-semibold">College Enquiry Assistant</h2>
        <p className="text-sm opacity-80">Ask me anything about our college</p>
      </div>
      
      <MessageList messages={messages} isTyping={isTyping} messagesEndRef={messagesEndRef} />
      <MessageInput onSendMessage={handleSendMessage} isTyping={isTyping} />
    </div>
  );
};

export default ChatbotInterface;