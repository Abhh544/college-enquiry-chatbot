import React from 'react';
import { Bot } from 'lucide-react';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex justify-start animate-fadeIn">
      <div className="flex max-w-[85%] flex-row">
        <div className="flex items-center justify-center h-8 w-8 rounded-full flex-shrink-0 bg-blue-100 text-blue-600 mr-2">
          <Bot size={18} />
        </div>
        
        <div>
          <div className="rounded-2xl py-3 px-4 bg-gray-100 text-gray-800 rounded-tl-none flex items-center">
            <span className="typing-dot"></span>
            <span className="typing-dot"></span>
            <span className="typing-dot"></span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;