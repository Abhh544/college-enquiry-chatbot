import React from 'react';
import { Message } from '../types/chatTypes';
import { formatTime } from '../utils/dateUtils';
import { User, Bot } from 'lucide-react';

interface MessageItemProps {
  message: Message;
}

const MessageItem: React.FC<MessageItemProps> = ({ message }) => {
  const isBot = message.sender === 'bot';
  
  return (
    <div 
      className={`flex ${isBot ? 'justify-start' : 'justify-end'} animate-fadeIn`}
    >
      <div 
        className={`flex max-w-[85%] ${isBot ? 'flex-row' : 'flex-row-reverse'}`}
      >
        <div 
          className={`flex items-center justify-center h-8 w-8 rounded-full flex-shrink-0 ${
            isBot ? 'bg-blue-100 text-blue-600 mr-2' : 'bg-indigo-100 text-indigo-600 ml-2'
          }`}
        >
          {isBot ? <Bot size={18} /> : <User size={18} />}
        </div>
        
        <div>
          <div 
            className={`rounded-2xl py-2 px-4 ${
              isBot 
                ? 'bg-gray-100 text-gray-800 rounded-tl-none' 
                : 'bg-indigo-600 text-white rounded-tr-none'
            }`}
          >
            {message.text}
          </div>
          <div 
            className={`text-xs text-gray-500 mt-1 ${
              isBot ? 'text-left' : 'text-right'
            }`}
          >
            {formatTime(message.timestamp)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageItem;