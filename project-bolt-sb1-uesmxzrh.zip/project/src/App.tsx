import React from 'react';
import ChatbotInterface from './components/ChatbotInterface';
import Header from './components/Header';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-100 flex flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center p-4">
        <ChatbotInterface />
      </main>
      <footer className="text-center p-4 text-gray-600 text-sm">
        © {new Date().getFullYear()} College Enquiry System • All Rights Reserved
      </footer>
    </div>
  );
}

export default App;