import { faqData } from '../data/faqData';

export const getResponse = async (query: string): Promise<string> => {
  // Convert query to lowercase for case-insensitive matching
  const lowercaseQuery = query.toLowerCase();
  
  // Check for exact matches in the FAQ data
  for (const key of Object.keys(faqData)) {
    if (lowercaseQuery.includes(key)) {
      return faqData[key];
    }
  }
  
  // If no exact match, try to find the most relevant response
  let bestMatch = '';
  let highestScore = 0;
  
  for (const key of Object.keys(faqData)) {
    // Simple word matching algorithm
    const keyWords = key.split(' ');
    let matchScore = 0;
    
    for (const word of keyWords) {
      if (lowercaseQuery.includes(word) && word.length > 2) {
        matchScore += 1;
      }
    }
    
    if (matchScore > highestScore) {
      highestScore = matchScore;
      bestMatch = key;
    }
  }
  
  // Return the best match if score is above threshold, otherwise return default message
  if (highestScore > 0) {
    return faqData[bestMatch];
  }
  
  return "I'm sorry, I don't have information about that. Please try asking about our admission process, fee structure, hostel facilities, placement records, or exam schedules.";
};