// FAQ data for the college enquiry chatbot
export const faqData: Record<string, string> = {
  "admission process": "Our admission process is straightforward. You need to fill out the online application form on our website and appear for the entrance test. Shortlisted candidates will be called for counseling sessions. The academic year typically begins in August.",
  
  "exam schedule": "Our semester exams are typically held in December and May. Mid-term evaluations are conducted in October and March. The exam timetable is published on the college portal at least 3 weeks before the exams begin.",
  
  "placement record": "We're proud of our excellent placement record! Last year, we achieved a 90% placement rate with top companies like Google, Microsoft, Amazon, TCS, Infosys, and Wipro visiting our campus. The highest package offered was 42 LPA and the average package was 8.5 LPA.",
  
  "fee structure": "The fee structure varies for each program. For B.Tech programs, the annual fee ranges from ₹1,20,000 to ₹1,50,000 depending on the branch. Hostel fees are approximately ₹80,000 per year. Scholarships are available for meritorious students and those from economically weaker sections.",
  
  "hostel facilities": "We provide separate hostels for boys and girls with excellent amenities. Each room accommodates 2-3 students and includes a bed, study table, chair, and wardrobe for each student. The hostels have Wi-Fi, 24/7 power backup, laundry services, gym, recreation rooms, and dining halls serving nutritious meals.",
  
  "library": "Our central library houses over 100,000 books, journals, and digital resources. It's open from 8 AM to 10 PM on weekdays and 9 AM to 5 PM on weekends. Students can borrow up to 5 books at a time for a period of 14 days.",
  
  "sports facilities": "The college has excellent sports facilities including a cricket ground, football field, basketball and volleyball courts, indoor games area, and a well-equipped gymnasium. We host annual sports meets and encourage students to participate in inter-college tournaments.",
  
  "scholarships": "We offer merit-based scholarships covering 25% to 100% of the tuition fees. Students with exceptional academic records or those who excel in sports/cultural activities are eligible. Additionally, we have special scholarships for students from economically weaker sections.",
  
  "internship opportunities": "Our college has tie-ups with over 200 companies that offer internship opportunities to students. The Training and Placement Cell coordinates internships during summer breaks. These internships often lead to pre-placement offers for our students.",
  
  "faculty": "We have a team of highly qualified faculty members with PhDs and extensive industry experience. The student-to-faculty ratio is 20:1, ensuring personalized attention and guidance for every student.",
  
  "courses offered": "We offer B.Tech programs in Computer Science, Information Technology, Electronics & Communication, Electrical, Mechanical, and Civil Engineering. We also have M.Tech programs in specialized fields and PhD programs for research enthusiasts.",
  
  "campus size": "Our campus spans over 100 acres of lush greenery with modern infrastructure. It includes academic blocks, research labs, hostels, staff quarters, a central library, administrative buildings, sports facilities, and recreational areas.",
  
  "canteen": "The college has multiple canteens and cafeterias serving a variety of cuisines at affordable prices. They operate from 7:30 AM to 10:30 PM, providing healthy and hygienic food options for students and staff.",
  
  "transportation": "We provide bus transportation facilities connecting various parts of the city to the college. The buses operate on fixed routes and schedules, making commuting convenient for day scholars."
};